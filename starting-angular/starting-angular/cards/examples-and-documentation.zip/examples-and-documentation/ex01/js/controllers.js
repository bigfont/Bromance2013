﻿function AppCtrl($scope) {
    'use strict';
    $scope.title = "AngularJS Hello World!";
}
AppCtrl.$inject = ['$scope'];