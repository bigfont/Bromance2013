﻿AppCtrl.$inject = ['$scope']
function AppCtrl($scope) {
    $scope.title = "AngularJS Hello World!";
}
